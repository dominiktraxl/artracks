# Geojson polygon antimeridian splitter

![github action](https://github.com/guidorice/antimeridian_splitter/actions/workflows/python-package.yml/badge.svg)

This code was copied from the blog post and git gists at:

https://towardsdatascience.com/around-the-world-in-80-lines-crossing-the-antimeridian-with-python-and-shapely-c87c9b6e1513

Original author: Pawarit Laosunthara, Senior Consultant at ThoughtWorks